AMAN MEDICARE AND DENTAL CENTER - Android project (starter build)

اہم:
- یہ Android Studio/AndroidIDE میں کھولنے کے لیے سورس پروجیکٹ ہے، APK فائل نہیں۔
- اس میں موجود HMS v0.4 HTML demo شامل ہے۔
- ایپ کا ڈیٹا اسی موبائل کے WebView local storage میں رہے گا۔
- یہ ابھی production-grade محفوظ medical system نہیں ہے۔ حقیقی مریضوں کا حساس ڈیٹا استعمال نہ کریں۔
- دو موبائلوں کی sync، encrypted database، مضبوط login/roles اور مکمل tested backup/restore ابھی شامل نہیں۔
- Print action Android Print Framework کھولنے کی کوشش کرتا ہے؛ Bluetooth thermal printer کی direct ESC/POS printing ابھی نہیں ہے۔

Build:
1) Android Studio یا AndroidIDE میں اس فولڈر کو Open کریں۔
2) Gradle sync مکمل ہونے دیں (انٹرنیٹ درکار ہو سکتا ہے)۔
3) Build > Build APK(s) منتخب کریں۔
4) Debug APK عموماً app/build/outputs/apk/debug/app-debug.apk میں بنتی ہے۔
5) APK انسٹال کرنے سے پہلے Android کی اجازت مانگنے پر صرف قابلِ اعتماد build کی اجازت دیں۔

Package: com.amanmedicare.app
App name: Aman Medicare
Min Android: Android 6.0 (API 23)
